#!/bin/bash

current_time=$(date "+%Y%m%d")
JKSFILE="/usr/prod/tesa/domains/tesaappdomain/tesaappserver_keystore.jks"
BACKUPJKSFILE="/usr/prod/tesa/domains/tesaappdomain/tesaappserver_keystore.jks_$current_time"
NEWJKS="/home/scripts/prod/TESA/tesaappserver_keystore.jks"

        echo "Backup the existing .jks file on C silo ${BACKUPJKSFILE}"
                for i in {670..684}; do
                sshpass -p 'swanaFruphuw37@UruCRUdreru*eXu' ssh -qT -o StrictHostKeyChecking=no tesadm@prdtesa${i} "cp -rp ${JKSFILE} ${BACKUPJKSFILE}"
                echo "Backup successfully completed on...prdtesa${i} server"
                sshpass -p 'swanaFruphuw37@UruCRUdreru*eXu' scp "${NEWJKS}" tesadm@prdtesa${i}:/usr/prod/tesa/domains/tesaappdomain/;
                echo "Copied SHA-2 JKS successfully on...prdtesa${i} server"
                done;

