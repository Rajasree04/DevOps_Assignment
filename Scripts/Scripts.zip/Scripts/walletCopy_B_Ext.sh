#!/bin/bash

        echo "Copying cacerts from $(hostname) to servers 073-080"
                for i in {073..080}; do
                current_time=$(date "+%Y%m%d")
                wallet="/usr/prod/qvcm/qvhsinst${i}/qvhsproxywallet/cwallet.sso"
                walletBACKUP="/usr/prod/qvcm/qvhsinst${i}/qvhsproxywallet/cwallet.sso_$current_time"
                NEWWALLET="/home/scripts/prod/QVOHS/cwallet.sso"
                sshpass -p '3=$=7s9uyUb5phU_ebUcExunAbEcru' ssh -qT -o StrictHostKeyChecking=no qvuadm@prdqvcm${i} "cp -rp ${wallet} ${walletBACKUP}"
                echo "Backup successfully completed on...prdqvcm${i} server"
                sshpass -p '3=$=7s9uyUb5phU_ebUcExunAbEcru' scp "${NEWWALLET}" qvuadm@prdqvcm${i}:/usr/prod/qvcm/qvhsinst${i}/qvhsproxywallet/;
                echo "Copied new wallet successfully on...prdqvcm${i} server"
                sshpass -p '3=$=7s9uyUb5phU_ebUcExunAbEcru' ssh -qT qvuadm@prdqvcm${i} "md5sum ${NEWWALLET}" 
                echo "Check sum done on...prdqvcm${i} server"
                done;

