#!/bin/bash
SERVERS="server1 server2 server3"
# SSH User name
USR="username"

# Logging
SUBJECT="Server user login report"
Log="connectivityCheck.txt"
# create new file
>$Log
 
# CONNECT TO EACH HOST CHECK THE CONNRCTIVITY
for host in $SERVERS
do
echo "-------------STARTUS:$SUBJECT-------------------" >>$Log
echo "* HOST: $host " >>$Log
echo "--------------------------------" >>$Log
ssh $USR@$host 
#we have to provide the destination and port no while execting the code 
#ex sh connectivityCheck.sh <<servername>> <<port>>
echo telenet $1 $2 >>$Log
done

