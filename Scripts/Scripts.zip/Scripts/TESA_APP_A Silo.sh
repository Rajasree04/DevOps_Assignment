#!/bin/bash

echo "Checking File System For TESA APP A Silo."
for i in {09..13}{26..35}
do 
SERVER="PRDTESA0$i"
echo "Checking the File System on PRDTESA0"$i
output = `ssh $SERVER ls /opt/wily`
echo $output 
echo "*****************************************************************"
output `ssh $SERVER ls /opt/oracle1036`
echo $output 
echo "*****************************************************************"
output = `ssh $SERVER ls /usr/prod/tesa`
echo $output 
echo "*****************************************************************"
output = `ssh $SERVER ls /var/prod/logs`
echo $output 
echo "*****************************************************************"
done


