#!/bin/bash
echo "This is the script for check the Disk Space"
read user_input
echo "$user_input"