#!/bin/bash
# SSH User name
USR="tesadm"

# Logging
SUBJECT="Server user login report"
Log="connectivityCheck.txt"
# create new file
>$Log
 
# CONNECT TO EACH HOST CHECK THE CONNRCTIVITY
for host in {052..066}
do
echo "---STARTUS:$SUBJECT---" >>$Log
echo " HOST: prdtesa${host} " >>$Log
echo "--------------------------------" >>$Log
ssh $USR@prdtesa${host} 
#we have to provide the destination and port no while execting the code 
#ex sh connectivityCheck.sh <<servername>> <<port>>
echo telenet $1 $2 >>$Log
echo "----------------------"
done

