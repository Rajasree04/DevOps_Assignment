#!/bin/bash
# SSH User name
USR="tesadm"
# Logging
SUBJECT="Server user login report"
Log="connectivityCheck.txt"
# create new file
>$Log
# CONNECT TO EACH HOST CHECK THE CONNRCTIVITY
for host in {052..066}
do
echo "---STARTUS:$SUBJECT---" >>$Log
echo " HOST: prdtesa${host} " >>$Log
echo "--------------------------------" >>$Log
ssh $USR@prdtesa${host} #this is used to login to the managed server
#we have to provide the destination and port no while executing the code 
#ex : sh connectivityCheck.sh <<server name>> <<port>>
echo telenet $1 $2 >>$Log
#continue # Skip destination if it is not connected.
echo "----------------------"
done

