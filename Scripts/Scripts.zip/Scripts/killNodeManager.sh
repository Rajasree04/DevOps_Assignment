#!/bin/bash

echo "*** Starting the script ***"
	for i in {600..620}; do
                sshpass -p '9-RaSusp?p#e&9acr9r4w_E#Utred@' ssh -qT -o StrictHostKeyChecking=no lcesadm@prdlces${i} "ps -fu $LOGNAME | grep weblogic.NodeManager | awk '{print $2}'"
                echo "Successfully connected to prdlces${i} server"
				sshpass -p '9-RaSusp?p#e&9acr9r4w_E#Utred@' ssh -qT -o StrictHostKeyChecking=no lcesadm@prdlces${i} "ps -fu $LOGNAME | grep weblogic.NodeManager | awk '{print $2}' | xargs -r kill"
				echo "Node Manager process has been killed on prdlces${i} server"
                done;