ls -ltr 
