#!/bin/bash

current_time=$(date "+%Y%m%d")
CACERTFILE="/apps/oracle1036/jdk1.7.0_79/jre/lib/security/cacerts"
BACKUPFILE="/apps/oracle1036/jdk1.7.0_79/jre/lib/security/cacerts_$current_time"
NEWCACERT="/home/scripts/prod/TMAG/cacerts"

        echo "Copying cacerts from $(hostname) to servers 002-016"
        echo "Previous version of cacerts will be backed up to ${BACKUPFILE}"
                for i in {002..016}; do
                sshpass -p 'zanuprA=Apu@Uce$paGe5ey2p278We' ssh -qT -o StrictHostKeyChecking=no tmagadm@prdtmag${i} "cp -rp ${CACERTFILE} ${BACKUPFILE}"
                echo "Backup successfully completed on...prdtmag${i} server"
                sshpass -p 'zanuprA=Apu@Uce$paGe5ey2p278We' scp "${NEWCACERT}" tmagadm@prdtmag${i}:/apps/oracle1036/jdk1.7.0_79/jre/lib/security/;
                echo "Copied new cacerts successfully on...prdtmag${i} server"
                sshpass -p 'zanuprA=Apu@Uce$paGe5ey2p278We' ssh -qT tmagadm@prdtmag${i} "md5sum ${CACERTFILE}" 
                echo "Check sum done on...prdtmag${i} server"
                done;

